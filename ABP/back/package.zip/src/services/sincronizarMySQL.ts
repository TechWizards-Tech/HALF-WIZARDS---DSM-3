import cron from 'node-cron';
import { mysqlConnection } from './mysql';
import { DadoMeteorologico } from '../models/DadoMeteorologico';

async function sincronizarDados() {
  console.log('⏰ Iniciando sincronização com MySQL...');

  try {
    const [rows] = await mysqlConnection.query('SELECT * FROM Sensor ORDER BY reading_time DESC LIMIT 10');
    const registros = rows as any[];

    for (const dado of registros) {
      await DadoMeteorologico.updateOne(
        { reading_time: dado.reading_time },
        { $set: dado },
        { upsert: true }
      );
    }

    console.log(`✅ ${registros.length} registros sincronizados do MySQL`);
  } catch (err) {
    console.error('❌ Erro ao sincronizar MySQL : ', err);
  }
}

export function iniciarSincronizacao() {
  // Executa imediatamente
  sincronizarDados();

  // Agenda para rodar a cada 10 minutos
  cron.schedule('*/10 * * * *', sincronizarDados);
}
